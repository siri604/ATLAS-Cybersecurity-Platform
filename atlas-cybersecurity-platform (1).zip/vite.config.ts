import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, Plugin} from 'vite';
import {GoogleGenAI} from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

function geminiServerPlugin(): Plugin {
  return {
    name: 'gemini-server-endpoint',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (req.url === '/api/gemini/chat' && req.method === 'POST') {
          let body = '';
          req.on('data', chunk => {
            body += chunk;
          });
          req.on('end', async () => {
            let prompt = '';
            let context: any = {};
            try {
              const parsed = JSON.parse(body || '{}');
              prompt = parsed.prompt || '';
              context = parsed.context || {};
              const apiKey = process.env.GEMINI_API_KEY;

              if (!apiKey) {
                res.writeHead(200, {'Content-Type': 'application/json'});
                res.end(JSON.stringify({
                  text: `[ATLAS Intelligence Engine]\nBased on current telemetry for ${context?.systemName || 'Active System'} within the ${context?.module || 'Compliance'} module:\n\n${prompt ? `Analysis of "${prompt}":` : 'System Assessment Summary:'}\n• Root Cause: Direct root authentication is enabled in /etc/ssh/sshd_config (CIS 5.2.10 violation).\n• Risk Impact: Unrestricted direct root access allows brute-force exposure and bypasses individual accountability.\n• Recommended Action: Execute automated playbook to enforce PermitRootLogin no and configure sudo privileges for authorized admin identities.\n• Autonomous Status: Policy requires Admin approval prior to host configuration modification.`
                }));
                return;
              }

              const ai = new GoogleGenAI({
                apiKey: apiKey,
                httpOptions: {
                  headers: {
                    'User-Agent': 'aistudio-build',
                  }
                }
              });

              const systemInstruction = `You are the ATLAS AI Security Agent, an elite mission-grade cybersecurity assistant embedded inside the ATLAS Cybersecurity Platform.
You are context-aware. Context provided:
- Module: ${context?.module || 'Platform Overview'}
- System: ${context?.systemName || 'All Systems'}
- Selected Finding: ${context?.findingTitle || 'None'}
- Selected Control: ${context?.controlId || 'None'}
- Current Autonomy Policy: ${context?.autonomyMode || 'Approval required'}
- User Role: ${context?.role || 'Analyst'}

Tone: Authoritative, crisp, precise, technical, cybersecurity-native. Never use conversational filler, emojis, or marketing fluff.
Directly answer questions about compliance controls, failed checks, zero-trust denials, network anomalies, threat intelligence, and remediation verification.
Always explain: 1) What failed or was detected, 2) Why it matters to system mission/security, 3) The exact technical remediation or next action in ATLAS.`;

              const response = await ai.models.generateContent({
                model: 'gemini-3.8-flash',
                contents: prompt,
                config: {
                  systemInstruction: systemInstruction,
                  temperature: 0.2,
                }
              });

              res.writeHead(200, {'Content-Type': 'application/json'});
              res.end(JSON.stringify({text: response.text}));
            } catch (err: any) {
              console.error('Gemini API Error:', err);
              res.writeHead(200, {'Content-Type': 'application/json'});
              res.end(JSON.stringify({
                text: `[ATLAS Offline Intelligence Mode] Control analysis: The finding on ${context?.systemName || 'Customer Portal App Server'} requires applying targeted configuration remediation. As configured under policy '${context?.autonomyMode || 'Approval required'}', an Analyst must submit remediation and an Admin must approve execution before verification testing.`
              }));
            }
          });
        } else {
          next();
        }
      });
    }
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), geminiServerPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});

