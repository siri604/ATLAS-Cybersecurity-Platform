import React, { useState } from 'react';
import { usePlatform } from '../../context/PlatformContext';
import { Shield, AlertTriangle, Cpu, CheckCircle2, ChevronRight, BarChart2, Radio, Lock, ShieldCheck, Network, Activity, Settings } from 'lucide-react';

const initialSituations = [
  {
    id: 1,
    name: 'Potential SSH Compromise',
    severity: 'High',
    entity: 'Customer Portal App Server',
    state: 'Approval Required',
    details: {
      affectedEntities: ['Customer Portal App Server', 'Privileged Admin Account', 'Suspicious External IP'],
      correlationReason: 'ATLAS detected anomalous SSH login pattern followed by unauthorized privileged account enumeration.',
      signals: [
        { module: 'Compliance', icon: ShieldCheck, text: 'CIS 5.2.10 drift detected, root SSH login enabled' },
        { module: 'IDS', icon: Radio, text: 'Repeated SSH authentication attempts detected' },
        { module: 'Network Security', icon: Network, text: 'Port 22 externally exposed' },
        { module: 'Anomaly Detection', icon: Activity, text: 'Unusual privileged login activity' },
        { module: 'Zero Trust', icon: Lock, text: 'Identity risk elevated' },
      ],
      assessment: 'Root SSH access is enabled while suspicious authentication activity is occurring. Multiple ATLAS modules indicate elevated risk of unauthorized privileged access to the Customer Portal App Server.',
      actions: [
        { name: 'Disable root SSH login', provider: 'SSH / OpenSCAP' },
        { name: 'Block malicious source IP', provider: 'Firewall' },
        { name: 'Revoke suspicious privileged session', provider: 'Identity Provider' },
        { name: 'Validate server health', provider: 'Health Check' },
        { name: 'Reassess affected CIS control', provider: 'Compliance' },
        { name: 'Verify suspicious SSH activity has stopped', provider: 'Network Security' },
      ],
      activity: [
        { time: '12:35:01', event: 'Situation detected', source: 'IDS', outcome: 'Correlated' },
        { time: '12:35:10', event: 'Correlation completed', source: 'ATLAS', outcome: 'High Risk' },
      ]
    }
  },
  { id: 2, name: 'Privileged Identity Risk', severity: 'High', entity: 'admin@customer.com', state: 'Investigating', details: { affectedEntities: [], correlationReason: '...', signals: [], assessment: '...', actions: [], activity: [] } },
  { id: 3, name: 'Ransomware Containment', severity: 'Critical', entity: 'Finance-WS-042', state: 'Executing', details: { affectedEntities: [], correlationReason: '...', signals: [], assessment: '...', actions: [], activity: [] } },
];

export const CognitiveOrchestration: React.FC = () => {
  const [situations, setSituations] = useState(initialSituations);
  const [selectedSituation, setSelectedSituation] = useState(situations[0]);
  const [missionState, setMissionState] = useState<'idle' | 'executing' | 'completed'>('idle');
  const [executionStep, setExecutionStep] = useState<number>(-1);

  React.useEffect(() => {
    if (missionState === 'executing') {
      if (executionStep < 5) {
        const timer = setTimeout(() => setExecutionStep(prev => prev + 1), 1500);
        return () => clearTimeout(timer);
      } else {
        setMissionState('completed');
        const updatedSituations = situations.map(s => s.id === 1 ? { ...s, state: 'Verified' } : s);
        setSituations(updatedSituations);
        setSelectedSituation(updatedSituations[0]);
      }
    }
  }, [missionState, executionStep, situations]);

  const timelineStages = ['Observe', 'Correlate', 'Decide', 'Approval Required', 'Execute', 'Verify'];

  return (
    <div className="space-y-6 font-sans">
      <h1 className="text-xl font-bold text-white tracking-wide">Cognitive Orchestration</h1>


      <div className="grid grid-cols-4 gap-4">
        {[
          { label: 'Active Situations', value: situations.length.toString(), icon: Shield },
          { label: 'Missions Awaiting Approval', value: situations.filter(s => s.state === 'Approval Required').length.toString(), icon: AlertTriangle },
          { label: 'Executing', value: situations.filter(s => s.state === 'Executing').length.toString(), icon: Cpu },
          { label: 'Verification Failed', value: '0', icon: CheckCircle2 },
        ].map((metric) => (
          <div key={metric.label} className="bg-[#0B121E] border border-slate-800/80 p-4 rounded-lg">
            <div className="flex items-center gap-2 text-slate-400 mb-1.5"><metric.icon className="w-3.5 h-3.5" /><span className="text-[10px] uppercase tracking-wider font-semibold">{metric.label}</span></div>
            <div className="text-2xl font-bold text-white font-mono">{metric.value}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-12 gap-6 h-[700px]">
        <div className="col-span-3 bg-[#0B121E] border border-slate-800/80 rounded-lg overflow-hidden flex flex-col">
          <div className="p-3 border-b border-slate-800/80 text-xs font-semibold text-white uppercase tracking-wider">Active Situations</div>
          <div className="flex-1 overflow-y-auto">
            {situations.map((sit) => (
              <button key={sit.id} onClick={() => { setSelectedSituation(sit); setMissionState('idle'); }} className={`w-full p-4 border-b border-slate-800/80 text-left hover:bg-[#0E1726] transition-colors ${selectedSituation.id === sit.id ? 'bg-[#0E1726]' : ''}`}>
                <div className="font-semibold text-white text-sm">{sit.name}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">Severity: {sit.severity}</div>
                <div className="text-[11px] text-slate-400">State: {sit.state}</div>
                <div className="flex flex-wrap gap-1 mt-2.5">
                  {sit.details.signals.slice(0, 3).map((sig, i) => (
                    <span key={i} className="text-[9px] bg-slate-900 text-slate-400 px-1.5 py-0.5 rounded uppercase tracking-wider border border-slate-800">{sig.module}</span>
                  ))}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="col-span-9 bg-[#0B121E] border border-slate-800/80 rounded-lg p-6 overflow-y-auto space-y-6">
          <h2 className="text-lg font-bold text-white tracking-wide">{selectedSituation.name}</h2>
          
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-6">
              <div>
                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Affected Entities</h3>
                <ul className="list-disc list-inside text-xs text-slate-300 space-y-1">
                  {selectedSituation.details.affectedEntities.map((e, i) => <li key={i}>{e}</li>)}
                </ul>
              </div>
              <div className="space-y-2">
                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Module Signals</h3>
                {selectedSituation.details.signals.map((sig, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs text-slate-300">
                    <span className="font-mono text-cyan-400 text-[10px] uppercase">{sig.module}</span> → {sig.text}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="space-y-6">
               <div className="bg-[#080C14] p-4 rounded border border-slate-800/80">
                 <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">ATLAS Assessment</h3>
                 <p className="text-xs text-slate-300 leading-relaxed">{selectedSituation.details.assessment}</p>
               </div>
               
               <div>
                 <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Recommended Mission</h3>
                 <div className="space-y-1.5">
                   {selectedSituation.details.actions.map((a, i) => (
                     <div key={i} className="flex justify-between items-center bg-[#080C14] p-2.5 rounded text-xs border border-slate-800/50">
                       <span className="text-slate-200">{i + 1}. {a.name}</span>
                       <span className="text-slate-500 font-mono text-[10px]">{a.provider}</span>
                     </div>
                   ))}
                 </div>
               </div>
            </div>
          </div>

          <div className="border-t border-slate-800/80 pt-6">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Mission Timeline</h3>
            <div className="text-[11px] text-slate-400 mb-3 font-mono">Governance Mode: <span className="text-slate-200">Approval Required</span></div>
            <div className="flex items-center gap-1.5 text-[11px] font-mono text-slate-500 mb-4">
              {timelineStages.map((stage, i) => {
                let status = '○';
                if (i < 3) status = '✓';
                else if (i === 3 && missionState !== 'idle') status = '✓';
                else if (i === 3 && missionState === 'idle') status = '●';
                else if (i === 4 && missionState === 'executing') status = '●';
                else if (i === 4 && missionState === 'completed') status = '✓';
                else if (i === 5 && missionState === 'completed') status = '✓';
                
                return (
                  <span key={stage} className={`px-2.5 py-1 rounded-sm ${status === '✓' ? 'text-emerald-400 bg-emerald-950/20' : status === '●' ? 'text-amber-400 bg-amber-950/20' : 'text-slate-500 bg-slate-900'}`}>
                    {stage} {status}
                  </span>
                );
              })}
            </div>
            {missionState === 'idle' && (
              <div className="flex gap-2">
                <button onClick={() => { setMissionState('executing'); setExecutionStep(0); }} className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-1.5 rounded text-xs font-medium transition-colors">Approve & Execute</button>
                <button className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-4 py-1.5 rounded text-xs font-medium transition-colors">Reject</button>
              </div>
            )}
            {missionState === 'executing' && (
              <div className="space-y-3">
                <h4 className="text-xs font-semibold text-white">Mission Execution</h4>
                {selectedSituation.details.actions.map((a, i) => (
                  <div key={i} className="flex justify-between text-xs p-2 bg-[#080C14] rounded">
                    <span className="text-slate-300">{a.name}</span>
                    <span className="font-mono text-[10px]">
                      {i < executionStep ? '✓ Completed' : i === executionStep ? '● Running' : '○ Pending'}
                    </span>
                  </div>
                ))}
              </div>
            )}
            {missionState === 'completed' && (
              <div className="space-y-4">
                <div className="text-sm font-semibold text-emerald-400">Mission Outcome: Verified</div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <h5 className="text-[10px] font-bold uppercase text-slate-400">Before</h5>
                    <div className="text-xs text-slate-300">Root SSH: Enabled</div>
                    <div className="text-xs text-slate-300">Identity risk: High</div>
                  </div>
                  <div className="space-y-1">
                    <h5 className="text-[10px] font-bold uppercase text-slate-400">After</h5>
                    <div className="text-xs text-emerald-400">Root SSH: Disabled</div>
                    <div className="text-xs text-emerald-400">Identity risk: Reduced</div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-slate-800/80 pt-6">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Mission Activity</h3>
            <div className="text-[11px] text-slate-400 space-y-1.5 font-mono">
              {(missionState === 'completed'
                ? [
                    { time: '12:35:15', event: 'Mission approved by Admin', source: 'ATLAS', outcome: 'Approved' },
                    { time: '12:35:16', event: 'Root SSH disabled', source: 'Compliance / SSH', outcome: 'Completed' },
                    { time: '12:35:17', event: 'Malicious source blocked', source: 'Network Security', outcome: 'Completed' },
                    { time: '12:35:18', event: 'Privileged session revoked', source: 'Zero Trust / Identity Provider', outcome: 'Completed' },
                    { time: '12:35:20', event: 'Mission verification completed', source: 'ATLAS', outcome: 'Verified' },
                  ]
                : selectedSituation.details.activity
              ).slice(-5).map((a, i) => (
                <div key={i} className="flex gap-4">
                  <span className="text-slate-500">[{a.time}]</span>
                  <span>{a.event}</span>
                  <span className="text-slate-500">• {a.source}</span>
                  <span className="text-slate-300 ml-auto">{a.outcome}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
